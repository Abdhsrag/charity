from rest_framework import generics
from user.api.serializers import ProjectSerializer
from project.models import Project

class ProfileProjectsView(generics.ListAPIView):
    serializer_class = ProjectSerializer

    def get_queryset(self):
        return Project.objects.filter(owner=self.request.user)