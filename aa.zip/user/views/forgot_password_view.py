from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from user.models import User
from user.api.serializers import PasswordResetSerializer
from user.api.tasks import send_password_reset_email

class ForgotPasswordView(APIView):
    def post(self, request):
        serializer = PasswordResetSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']

        try:
            user = User.objects.get(email=email)
            send_password_reset_email(user)
        except User.DoesNotExist:
            pass

        return Response({'message': 'If the email is registered, a reset link has been sent.'}, status=status.HTTP_200_OK)