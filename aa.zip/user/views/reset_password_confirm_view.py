from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from user.api.serializers import PasswordResetConfirmSerializer

class ResetPasswordConfirmView(APIView):
    def post(self, request, uidb64, token):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(uidb64, token)
        return Response({'message': 'Password reset successful.'}, status=status.HTTP_200_OK)