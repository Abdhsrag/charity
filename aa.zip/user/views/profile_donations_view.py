from rest_framework import generics
from user.api.serializers import DonationSerializer
from donations.models import Donation

class ProfileDonationsView(generics.ListAPIView):
    serializer_class = DonationSerializer

    def get_queryset(self):
        return Donation.objects.filter(user=self.request.user)