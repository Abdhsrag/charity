from rest_framework import generics, status
from rest_framework.response import Response
from user.models import User
from user.api.serializers import RegisterSerializer
from user.api.tasks import send_activation_email

class RegisterView(generics.CreateAPIView):
    serializer_class = RegisterSerializer

    def perform_create(self, serializer):
        user = serializer.save(is_active=False)
        send_activation_email(user)