from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from social_django.utils import psa
from rest_framework_simplejwt.tokens import RefreshToken
from user.models import User

class FacebookLoginView(APIView):
    @psa('social:complete')
    def post(self, request, backend='facebook'):
        token = request.data.get('access_token')
        if not token:
            return Response({'error': 'Access token required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = request.backend.do_auth(token)
        except Exception:
            return Response({'error': 'Invalid Facebook token or error during authentication'}, status=status.HTTP_400_BAD_REQUEST)

        if user and user.is_active:
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            })
        else:
            return Response({'error': 'User inactive or not found'}, status=status.HTTP_400_BAD_REQUEST)