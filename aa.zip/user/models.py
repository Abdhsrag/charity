from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)  # hashes password
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    Fname = models.CharField(max_length=100)
    Lname = models.CharField(max_length=100)
    email = models.EmailField(unique=True, max_length=100)  # Login field
    Mphone = models.CharField(max_length=20)
    image = models.ImageField(upload_to='user/imgs', blank=True, null=True)
    
    TYPE_CHOICES = [
        ('admin', 'Admin'),
        ('owner', 'Owner'),
        ('donor', 'Donor'),
    ]
    Type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    
    Bdate = models.DateField(null=True, blank=True)
    Regist_date = models.DateTimeField(auto_now_add=True)
    Facebook_url = models.TextField(default=None, null=True)
    Country = models.CharField(max_length=100)

    is_active = models.BooleanField(default=False)  # Needed for account activation
    is_staff = models.BooleanField(default=False)   # Needed for admin login
    is_superuser = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['Fname', 'Lname', 'Mphone', 'Type', 'Country']

    def __str__(self):
        return f"{self.Fname} {self.Lname} ({self.email})"
