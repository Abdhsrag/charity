from django.urls import path
from user.views import (
    RegisterView,
    ActivateAccountView,
    LoginView,
    FacebookLoginView,
    ForgotPasswordView,
    ResetPasswordConfirmView,
    ProfileProjectsView,
    ProfileDonationsView,
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('activate/<uidb64>/<token>/', ActivateAccountView.as_view(), name='activate-account'),
    path('login/', LoginView.as_view(), name='login'),
    path('login/facebook/', FacebookLoginView.as_view(), name='facebook-login'),
    path('password/forgot/', ForgotPasswordView.as_view(), name='forgot-password'),
    path('password/reset/<uidb64>/<token>/', ResetPasswordConfirmView.as_view(), name='reset-password'),
    path('profile/projects/', ProfileProjectsView.as_view(), name='profile-projects'),
    path('profile/donations/', ProfileDonationsView.as_view(), name='profile-donations'),
]
