# from rest_framework import viewsets
# from ..models import User
# from .serializers import UserSerializer

# class UserViewSet(viewsets.ModelViewSet):
#     queryset = User.objects.all()
#     serializer_class = UserSerializer
# from rest_framework import generics, status
# from rest_framework.response import Response
# from .serializers import RegisterSerializer
# from .models import User
# from .tasks import send_activation_email  # Assuming you're using Celery

# class RegisterView(generics.CreateAPIView):
#     serializer_class = RegisterSerializer

#     def perform_create(self, serializer):
#         user = serializer.save(is_active=False)  # User starts inactive
#         send_activation_email(user)  # Async task to send email
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from django.contrib.auth.tokens import default_token_generator
# from django.utils.http import urlsafe_base64_decode
# from django.utils.encoding import force_str
# from .models import User

# class ActivateAccountView(APIView):
#     def get(self, request, uidb64, token):
#         try:
#             uid = force_str(urlsafe_base64_decode(uidb64))
#             user = User.objects.get(pk=uid)
#         except (TypeError, ValueError, OverflowError, User.DoesNotExist):
#             return Response({'error': 'Invalid activation link.'}, status=status.HTTP_400_BAD_REQUEST)

#         if user.is_active:
#             return Response({'message': 'Account already activated.'}, status=status.HTTP_200_OK)

#         if default_token_generator.check_token(user, token):
#             user.is_active = True
#             user.save()
#             return Response({'message': 'Account activated successfully.'}, status=status.HTTP_200_OK)
#         else:
#             return Response({'error': 'Invalid or expired token.'}, status=status.HTTP_400_BAD_REQUEST)
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from django.contrib.auth import authenticate
# from rest_framework_simplejwt.tokens import RefreshToken
# from .serializers import LoginSerializer

# class LoginView(APIView):
#     def post(self, request):
#         serializer = LoginSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         user = serializer.validated_data['user']

#         refresh = RefreshToken.for_user(user)
#         return Response({
#             'refresh': str(refresh),
#             'access': str(refresh.access_token),
#         }, status=status.HTTP_200_OK)
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from social_django.utils import psa
# from rest_framework_simplejwt.tokens import RefreshToken
# from .models import User

# class FacebookLoginView(APIView):
#     """
#     Expects POST with access_token from Facebook.
#     """
#     @psa('social:complete')  # Required to hook into the PSA pipeline
#     def post(self, request, backend='facebook'):
#         token = request.data.get('access_token')
#         if not token:
#             return Response({'error': 'Access token required'}, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             user = request.backend.do_auth(token)
#         except Exception:
#             return Response({'error': 'Invalid Facebook token or error during authentication'}, status=status.HTTP_400_BAD_REQUEST)

#         if user and user.is_active:
#             refresh = RefreshToken.for_user(user)
#             return Response({
#                 'refresh': str(refresh),
#                 'access': str(refresh.access_token),
#             })
#         else:
#             return Response({'error': 'User inactive or not found'}, status=status.HTTP_400_BAD_REQUEST)
