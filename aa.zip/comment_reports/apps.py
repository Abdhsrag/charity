from django.apps import AppConfig


class CommentsReportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comment_reports'
